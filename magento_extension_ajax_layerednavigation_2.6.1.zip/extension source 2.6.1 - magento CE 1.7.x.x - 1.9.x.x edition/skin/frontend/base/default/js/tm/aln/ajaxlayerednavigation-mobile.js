var LayeredNavigationMobile = Class.create();
LayeredNavigationMobile.prototype = {
    initialize : function(config) {
        this.currencySymbol = config.currencySymbol;
        this.formattedPriceSample = config.formattedPriceSample;
        this.slider = parseInt(config.slider);
        this.seoUrls = parseInt(config.seoUrls);
        this.seoCategory = config.seoCategory;
        this.seoSuffix = config.seoSuffix;
        this.mageSuffix = config.mageSuffix;
        this.categoryUrl = config.categoryUrl;
        this.currentUrl = this.categoryUrl;
        this.isHome = parseInt(config.isHome);
        this.isCatalogSearch = parseInt(config.isCatalogSearch);
        this.searchQuery = config.searchQuery;
        this.isAjax = parseInt(config.isAjax);
        this.mobileNavigationActive = false;
        this.mobileSliderInit = false;
        this.activeFilters = [];
        this.priceslider = null;
        this.sliders = [];
        this.sliderData = {};
        if (this.slider) {
            this._initMobileSliders();
        }
        this._initMobileNavigation();
        this._initOrientationChangeEvent();
    },

    _initOrientationChangeEvent : function() {
        var self = this;
        jQuery(window).on("orientationchange", function(event) {
            jQuery("#mobile-layered-navigation").removeClass("aln-mobile-nav-show");
            jQuery("#mobile-layered-navigation").addClass("aln-mobile-nav-hide");
            jQuery('#aln-overlay').removeClass('aln-shown');
            jQuery('.ajaxlayerednavigation-sliders').each(function() {
                jQuery(this).ionRangeSlider("remove");
            });
            setTimeout(function() {
                self._initMobileSliders(true);
            }, 1000);
        });
        jQuery('#aln-overlay').click(function() {
            self.openMobileNavigation();
        });
    },

    _initMobileNavigation : function() {
        jQuery('.aln-mobile-button').insertBefore('.category-products');

        var self = this;
        jQuery("#mobile-layered-navigation").on("swipeleft", function() {
            ajaxLayeredNavigationMobile.openMobileNavigation();
        });

        jQuery('.aln-close-mobile-nav').click(function(e) {
            e.preventDefault();
            self.openMobileNavigation();
        });

        jQuery('#aln-overlay').on("swipeleft", function() {
            ajaxLayeredNavigationMobile.openMobileNavigation();
        });

        jQuery('.aln-mobile-button').click(function() {
            self.openMobileNavigation();
        });

        jQuery('.aln-option-switch').click(function() {
            self.reload(jQuery(this).closest("a")[0].href);
            jQuery(this).toggleClass("switchOn");
        });

        jQuery('.aln-state-chip-remove').click(function() {
            self.reload(jQuery(this).data("href"));
        });

        jQuery('.aln-mobile-clear-all').click(function(e) {
            e.preventDefault();
            self.reload(jQuery(this)[0].href);
        });
        //toolbar
        $$('div.sort-by select').each(function(el) {
            el.stopObserving('change');
            el.onchange = function() {
                return false;
            }
            Event.observe(el, 'change', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el).val(), true);
                } else {
                    var url = jQuery(el).val(),
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        $$('div.sort-by a').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el)[0].href, true);
                } else {
                    var url = jQuery(el)[0].href,
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        $$('a.sort-dir').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el)[0].href, true);
                } else {
                    var url = jQuery(el)[0].href,
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        $$('a.list').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el)[0].href, true);
                } else {
                    var url = jQuery(el)[0].href,
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        $$('a.grid').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el)[0].href, true);
                } else {
                    var url = jQuery(el)[0].href,
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        $$('div.limiter select').each(function(el) {
            el.stopObserving('change');
            el.onchange = function() {
                return false;
            };
            Event.observe(el, 'change', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el).val(), true);
                } else {
                    var url = jQuery(el).val(),
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        $$('div.pages li a').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                jQuery('#aln-overlay').addClass('aln-shown');
                if (!self.seoUrls) {
                    self.reload(jQuery(el)[0].href, true);
                } else {
                    var url = jQuery(el)[0].href,
                        query = url.split("?"),
                        params = query[1];
                    self.reload(self.buildToolbarSeoUrl(params), true);
                }
            });
        });

        jQuery(".aln-mobile-item .aln-mobile-attribute-title").click(function(e) {
            e.preventDefault();
            if (jQuery(this).hasClass('aln-mobile-show-hide-minus')) {
                jQuery(this).next().slideUp();
                jQuery(this).removeClass("aln-mobile-show-hide-minus");
                self.activeFilters = self.removeArrayItem(self.activeFilters, jQuery(this)[0].id);
            } else {
                if (-1 == self.activeFilters.indexOf(jQuery(this)[0].id)) {
                    self.activeFilters.push(jQuery(this)[0].id);
                }
                jQuery(this).next().slideDown();
                jQuery(this).addClass("aln-mobile-show-hide-minus");
            }
        });
    },

    buildToolbarSeoUrl: function(params) {
        if (this.currentUrl == this.categoryUrl) {
            var result = "", url = this.currentUrl;
            url = url.replace(this.mageSuffix,"");
            if (this.isCatalogSearch) {
                result = url + this.seoSuffix;
                var requestParams = params.split("&"), item = "";
                requestParams.each(function(param){
                    item = param.split("=");
                    result += "/" + item[0] + "/" + item[1];
                });
                result += "/q/" + this.searchQuery + this.mageSuffix;
            } else {
                result = url + "/" + this.seoSuffix + "/f";
                var requestParams = params.split("&"), item = "";
                requestParams.each(function(param){
                    item = param.split("=");
                    result += "/" + item[0] + "/" + item[1];
                });
                result += this.mageSuffix;
            }

            return result;
        } else {
            var url = this.currentUrl,
                urlParams = [],
                query = {},
                category = this.categoryUrl;
            category = category.replace(this.mageSuffix,"");
            url = url.replace(this.mageSuffix,"");
            url = url.replace(category, "");
            if (this.isCatalogSearch) {
                url = url.replace(this.seoSuffix + "/", "");
            } else {
                url = url.replace("/" + this.seoSuffix + "/f/", "");
            }
            urlParams = url.split("/");
            for (var i = 0; i < urlParams.length; i++) {
                if (i % 2 == 0) {
                    query[urlParams[i]] = urlParams[i + 1];
                }
            }
            //toolbar params
            var requestParams = params.split("&"), item = "";
            requestParams.each(function(param){
                item = param.split("=");
                query[item[0]] = item[1];
            });

            if (this.isCatalogSearch) {
                query["q"] = this.searchQuery;
            }
            query = this.sortSeoQuery(query);
            if (this.isCatalogSearch) {
                url = category + this.seoSuffix;
            } else {
                url = category + "/" + this.seoSuffix + "/f";
            }
            for (var option in query) {
                url += "/" + option + "/" + query[option];
            }
            url += this.mageSuffix;

            return url;
        }
    },

    removeArrayItem: function(arr) {
        var what, a = arguments, L = a.length, ax;
        while (L > 1 && arr.length) {
            what = a[--L];
            while ((ax= arr.indexOf(what)) !== -1) {
                arr.splice(ax, 1);
            }
        }
        return arr;
    },

    reload : function(url, toolbar) {
        this.showLoader();
        url = decodeURIComponent(url);
        this.currentUrl = url;
        var parser = document.createElement('a');
        parser.href = this.currentUrl;
        url = url.replace(/https{0,1}\:/, window.location.protocol);
        url = url.replace(parser.hostname, window.location.hostname);

        var self = this;
        if (this.isAjax) {
            new Ajax.Request(url, {
                method : 'get',
                onSuccess : function(transport) {
                    var response = transport.responseText.evalJSON();
                    jQuery(".aln-mobile-button").remove();
                    var colmain = $$('div.col-main')[0];
                    if ("undefined" == typeof colmain) {
                        colmain = $$('div.column-main')[0];
                    }
                    colmain.update(response.brend + response.list);
                    // $$('div.col-main')[0].update(response.brend + response.list);
                    $$('#mobile-layered-navigation')[0].replace(response.filter);
                    self._initMobileNavigation();
                    if (self.slider) {
                        self._initMobileSliders();
                    }
                    self.activeFilters.each(function(id){
                        jQuery("#" + id).addClass("aln-mobile-show-hide-minus");
                        jQuery("#" + id).next().show();
                    });

                    if (toolbar) {
                        jQuery('#aln-overlay').removeClass('aln-shown');
                    } else {
                        jQuery("#mobile-layered-navigation").addClass("aln-mobile-nav-show");
                    }
                    self.hideLoader();
                    // AjaxPro add observers
                    if (typeof AjaxPro !== "undefined") {
                        AjaxPro.fire('addObservers');
                    }
                    //quickshoping fix
                    if (typeof initQuickShoppingJs !== "undefined") {
                        $('lightwindow') && $('lightwindow').remove();
                        $('lightwindow_overlay') && $('lightwindow_overlay').remove();
                        initQuickShoppingJs();
                    }
                    // fire event product list ready
                    document.fire("ajaxlayerednavigation:ready");
                },
                onFailure: function() {
                    self.hideLoader();
                }
            });
        } else {
            window.location.href = url;
        };
    },

    _initMobileSliders : function(orient) {
        var self = this;
        jQuery('.ajaxlayerednavigation-sliders').each(function() {
            jQuery(this).closest("ul").show();
            var prices = jQuery(this).val(),
                priceData = prices.split(';'),
                id = jQuery(this).attr('id'),
                requestVar = id.substr(22);
            if (!self.mobileSliderInit) {
                self.sliderData[requestVar] = {
                    min: priceData[0],
                    max: priceData[1],
                    from: priceData[0],
                    to: priceData[1]
                }
            } else {
                if (!orient) {
                    self.sliderData[requestVar].from = priceData[0];
                    self.sliderData[requestVar].to = priceData[1];
                }
            }
            jQuery(this).val(self.sliderData[requestVar].min + ";" + self.sliderData[requestVar].max);
            prefixSymbol = '';
            postfixSymbol = '';
            if ('price' == requestVar) {
                if (self.formattedPriceSample.indexOf(self.currencySymbol) > 0) {
                    postfixSymbol = ' ' + self.currencySymbol;
                } else {
                    prefixSymbol = self.currencySymbol;
                };
            }
            jQuery(this).ionRangeSlider({
                request: requestVar,
                min: parseInt(self.sliderData[requestVar].min),
                max: parseInt(self.sliderData[requestVar].max),
                from: parseInt(self.sliderData[requestVar].from),
                to: parseInt(self.sliderData[requestVar].to),
                type: "double",
                step: 1,
                prefix: prefixSymbol,
                postfix: postfixSymbol,
                prettify: false,
                hasGrid: true,
                hideMinMax: true,
                hideFromTo: true,
                onFinish: function(obj) {
                    self.sliderData[obj.request].from = obj.fromNumber;
                    self.sliderData[obj.request].to = obj.toNumber;
                    if (!self.seoUrls) {
                        var priceUrl = self.buildUrl(
                            self.currentUrl,
                            obj.request,
                            obj.fromNumber + "," + obj.toNumber
                        );
                        self.reload(priceUrl);
                    } else {
                        self.reload(
                            self.buildSliderSeoUrl(
                                obj.request,
                                obj.fromNumber+","+obj.toNumber
                            )
                        );
                    }
                }
            });
            jQuery(this).closest("ul").hide();
        });
        this.mobileSliderInit = true;
    },

    buildSliderSeoUrl: function(varName, sliderValues) {
        if (this.currentUrl == this.categoryUrl) {
            var result = "", url = this.currentUrl;
            url = url.replace(this.mageSuffix,"");
            if (this.isCatalogSearch) {
                result = url + this.seoSuffix + "/" + varName + "/" + sliderValues + "/q/" + this.searchQuery + this.mageSuffix;
            } else {
                result = url + "/" + this.seoSuffix + "/f/" + varName + "/" + sliderValues + this.mageSuffix;
            }
            return result;
        } else {
            var url = this.currentUrl,
                params = [],
                query = {},
                category = this.categoryUrl;
            category = category.replace(this.mageSuffix,"");
            url = url.replace(this.mageSuffix,"");
            url = url.replace(category, "");
            if (this.isCatalogSearch) {
                url = url.replace(this.seoSuffix + "/", "");
            } else {
                url = url.replace("/" + this.seoSuffix + "/f/", "");
            }

            params = url.split("/");
            for (var i = 0; i < params.length; i++) {
                if (i % 2 == 0) {
                    query[params[i]] = params[i + 1];
                }
            }
            query[varName] = sliderValues;
            if (this.isCatalogSearch) {
                query["q"] = this.searchQuery;
            }
            query = this.sortSeoQuery(query);
            if (this.isCatalogSearch) {
                url = category + this.seoSuffix;
            } else {
                url = category + "/" + this.seoSuffix + "/f";
            }
            for (var option in query) {
                url += "/" + option + "/" + query[option];
            }

            url += this.mageSuffix;

            return url;
        }
    },

    sortSeoQuery: function(query) {
        var keys = Object.keys(query),
            i, len = keys.length
            output = {};
        keys.sort();
        for (i = 0; i < len; i++) {
            k = keys[i];
            output[k] = query[k];
        }

        return output;
    },

    buildUrl: function(url, param, paramVal) {
        var newAdditionalURL = "";
        var tempArray = url.split("?");
        var baseURL = tempArray[0];
        var additionalURL = tempArray[1];
        var temp = "";
        if (additionalURL) {
            tempArray = additionalURL.split("&");
            for (i=0; i<tempArray.length; i++){
                if(tempArray[i].split('=')[0] != param){
                    newAdditionalURL += temp + tempArray[i];
                    temp = "&";
                }
            }
        }

        var rows_txt = temp + "" + param + "=" + paramVal;
        if (this.isCatalogSearch) {
            if (this.currentUrl == this.categoryUrl) {
                rows_txt += "&q=" + this.searchQuery;
            }
        }
        return baseURL + "?" + newAdditionalURL + rows_txt;
    },

    openMobileNavigation : function() {
        var self = this;

        if (this.mobileNavigationActive) {
            // close navigation
            jQuery("#mobile-layered-navigation").css('transition-duration','0.2s');
            jQuery("#mobile-layered-navigation").removeClass("aln-mobile-nav-show");
            jQuery("#mobile-layered-navigation").addClass("aln-mobile-nav-hide");
            jQuery('#aln-overlay').removeClass('aln-shown');
            jQuery('html, body').animate({
                scrollTop: jQuery('.category-title').offset().top
            }, 500);
            this.mobileNavigationActive = false;
        } else {
            jQuery("#mobile-layered-navigation").css('transition-duration','0.2s');
            jQuery("#mobile-layered-navigation").removeClass("aln-mobile-nav-hide");
            jQuery("#mobile-layered-navigation").addClass("aln-mobile-nav-show");
            jQuery('#aln-overlay').addClass('aln-shown');
            this.mobileNavigationActive = true;
        }
    },

    showLoader: function() {
        jQuery(".aln-mobile-loader").show();
        jQuery('.aln-mobile-loader').css('z-index', 1001);
        jQuery('#aln-overlay').addClass('aln-shown');
        jQuery('#aln-overlay').css('z-index', 1000);
    },

    hideLoader: function() {
        jQuery('#aln-overlay').css('z-index', 999);
        jQuery(".aln-mobile-loader").hide();
    }
};
