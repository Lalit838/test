var LayeredNavigation = Class.create();
LayeredNavigation.prototype = {
    initialize : function(config) {
        this.layerStyle = parseInt(config.layerStyle);
        this.countOption = config.countOption;
        if (null == this.countOption) {
            this.countOption = 0;
        }
        if ($$('div.ajaxlayerednav-content')[0]) {
            this.layerStyle = 0;
        }
        this.slidersValues = {};
        this.useAjax = parseInt(config.useAjax);
        this.seoUrls = parseInt(config.seoUrls);
        this.isCatalogSearch = config.isCatalogSearch;
        this.isAdvancedSearch = config.isAdvancedSearch;
        this.searchQuery = config.searchQuery;
        this.seoCat  = config.seoCategory;
        this.seoSuffix = config.seoSuffix;
        this.fixedHeight = parseInt(config.fixedHeight);
        this.sliderFlag = 0;
        this.minRange = parseInt(config.minRange);
        this.maxRange = parseInt(config.maxRange);
        this.minPrice = parseInt(config.minPrice);
        this.maxPrice = parseInt(config.maxPrice);
        this.priceErrorText = config.priceErrorText;
        this.priceButton = false;
        this.mediaUrl = config.mediaUrl;
        this.intervalId = '';
        this.urlHash = '';
        this.categoryUrl = config.categoryUrl;
        this.home = parseInt(config.isHome);
        this.currentUrlParams = document.location.search;
        if (this.layerStyle != 0) {
            this.hideAllOptions();
        }
        this.prepareMarkup();
        this.addObservers();
        this.checkUrlHash();
    },

    prepareMarkup: function() {
        var self = this;
        if (this.layerStyle == '3') {
            var dt = '';
            $$('div.block-layered-nav dd').each(function(el){
                if (!el.hasClassName('ajaxlayerednavigation-price')) {
                    dt = el.up();
                    if (!dt.hasClassName('active')) {
                        el.hide();
                    } else {
                        el.show();
                    }
                } else {
                    dt = el.up();
                    if (!dt.hasClassName('active')) {
                        setTimeout(function() {
                            el.hide();
                        }.bind(this), 100);
                    } else {
                        $(el).blindDown();
                    }
                }
            });
        }
        if (this.layerStyle == '2') {
            var dt = '';
            var dim = null;
            $$('div.block-layered-nav dd').each(function(el){
                dim = el.getDimensions();
                if (dim.height > self.fixedHeight) {
                    el.setStyle({
                       'height': self.fixedHeight + 'px',
                       'overflow' : 'auto'
                    });
                }
            });
        }
        if (this.layerStyle == 0 || this.layerStyle == '4') {
            $$('div.block-layered-nav dd').each(function(el){
                el.hide();
            });
        }
    },

    prepareStyleMarkup: function() {
        if (this.layerStyle == '3') {
            self = this;
            var dt = '',
                inputs = null,
                priceVar = '',
                elVar = '',
                active = false,
                dd = '';

            $$('div.block-layered-nav dd').each(function(el){
                dt = el.previous();
                inputs = el.select('input');
                inputs.each(function(checkbox){
                    if (checkbox.hasClassName('ajaxlayerednavigation-sliders')) {
                        priceVar = checkbox.id.replace('ajaxlayerednavigation-', '');
                        var params = self._getAllUrlParams(self.currentUrl);
                        if (!params.each) {
                            for(var i in params) {
                                if (priceVar == i) {
                                    active = true;
                                }
                            }
                        } else {
                            params.each(function(el){
                                elVar = el.split("=");
                                if (priceVar == elVar[0]) {
                                    active = true;
                                }
                            });
                        }
                    } else {
                        if (checkbox.checked) {
                            active = true;
                        }
                    }
                });

                if (active) {
                    setTimeout(function() {
                        Effect.BlindDown($(el), { duration: 0.3 });
                    }, 100);

                    dt.addClassName('active');
                    active = false;
                }
            });
        }
    },

    showHideOption : function(el) {
        if (this.layerStyle != '1') {
            return false;
        }
        if (this.countOption == 0) {
            return false;
        }
        var dd = el.up();
        if (dd.hasClassName('full-list')) {
            dd.removeClassName('full-list');
            this.hideCurrentOption(dd);
            var hide = dd.down('a.see-all-hide');
            var show = dd.down('a.see-all-show');
            hide.hide();
            show.show();
        } else {
            var li = dd.select('li');
            dd.addClassName('full-list');
            li.each(function(el) {
                if ($(el).getStyle('display') == 'none') {
                    $(el).blindDown({
                        duration: 0.3
                    });
                }
            });
            var aHide = dd.down('a.see-all-hide');
            var aShow = dd.down('a.see-all-show');
            aHide.show();
            aShow.hide();
        }
    },

    showHideTop : function(el) {
        if (this.layerStyle != '1') {
            return false;
        }
        if (this.countOption == 0) {
            return false;
        }

        var dd = el.next();
        var search = dd.down();
        if (search.value) {
            return false;
        }
        if (this.layerStyle == 3) {
            if (dd.hasClassName('full-list')) {
                dd.removeClassName('full-list');
                this.hideCurrentOption(dd);
                var hide = dd.down('a.see-all-hide');
                var show = dd.down('a.see-all-show');
                hide.hide();
                show.show();
            } else {
                var li = dd.select('li');
                if (li.length > this.countOption) {
                    dd.addClassName('full-list');
                    li.each(function(el) {
                        $(el).blindDown({ duration: 0.3 });
                    });
                    var aHide = dd.down('a.see-all-hide');
                    var aShow = dd.down('a.see-all-show');
                    aHide.show();
                    aShow.hide();
                }
            }
        }
    },

    hideCurrentOption : function(el) {
        if (this.countOption == 0) {
            return false;
        }
        if (this.layerStyle == '1' && parseInt(this.countOption) > 0) {
            var self = this;
            var i = 1;
            var li = el.select('li');
            li.each(function(el) {
                if (i > parseInt(self.countOption)) {
                    $(el).blindUp({ duration: 0.3 });
                    //el.hide();
                }
                i++;
            });
        }
    },

    hideAllOptions : function() {
        if (this.countOption == 0) {
            return false;
        }
        if (this.layerStyle == '1' && parseInt(this.countOption) > 0) {
            var self = this;
            $$('.block-layered-nav dd').each(function(el) {
                var i = 1;
                var showLink = false;
                var li = el.select('li');
                li.each(function(el) {
                    if (i > parseInt(self.countOption)) {
                        $(el).blindUp({ duration: 0.3 });
//                        el.hide();
                        showLink = true;
                    }
                    i++;
                });
                if (showLink) {
                  var aShow = el.down('a.see-all-show');
                    aShow.show();
                }
            });
        }
    },

    showActivOptions : function(el) {
        if (el.next().hasClassName('active')) {
            el.removeClassName('active-title');
            el.next().removeClassName('active');
            el.next().hide();
        } else {
            $$('.block-layered-nav dd').invoke('hide');

            if (this.layerStyle == '2') {
                el.next().setStyle({
                    'position' : 'absolute',
                    'top' : offset.top + height + 'px',
                    'left' : offset.left + 'px'
                }).show();
            }

            this.hideAllNotActive();
            el.next().addClassName('active');
            el.addClassName('active-title');
        }

    },
    hideAllNotActive : function() {
        $$('.ajaxlayerednav-content dd').each(function(el) {
            if (el.hasClassName('active')) {
                el.removeClassName('active');
                el.hide();
            }
        });
    },

    getSeoQuery : function(query) {
        query = query.replace('?','');
        var newQuery = query.split('&');
        var params = {};
        var splitItem = [];
        newQuery.each(function(item){
            splitItem = item.split('=');
            params[splitItem[0]] = splitItem[1];
        });
        return params;
    },

    apllySlidersValues: function(varName, from, to) {
        var self = this;
        if (!self.seoUrls) {
            var query = self.getUrlQuery(self.categoryUrl);
            var url = '';
            if (query) {
                url = self.categoryUrl + query;
            } else {
                url = self.categoryUrl;
            }
            self.reload.bind(self, url)();
        } else {
            var objectParams = {};
            objectParams[varName] = from + ',' + to;
            self.reload(self._buildSeoQuery(objectParams));
        }
    },

    addObservers : function() {
        var self = this;
        if (this.layerStyle == '3') {
            $$('div.block-layered-nav dt').each(function(el) {
                Event.observe(el, 'click', function(e) {
                    e.stop();
                    var dd = el.next();
                    if (el.hasClassName('active')) {
                        Effect.BlindUp($(dd), { duration: 0.5 });
                        el.removeClassName('active');
                    } else {
                        Effect.BlindDown($(dd), { duration: 0.5 });
                        el.addClassName('active');
                    }

                });
            });
        }

        if (this.layerStyle == 0) {
            $$('div.ajaxlayerednav-content dt').each(function(el) {
                Event.observe(el, 'click', function(e) {
                    e.stop();
                    var dd = el.next();
                    if (dd.hasClassName('active')) {
                        $(dd).hide();
                        dd.removeClassName('active');
                    } else {
                        self.hideAllNotActive();
                        var blockNav = el, offset = blockNav.positionedOffset(), height = blockNav.getHeight();
                        width = $$('.block-layered-nav')[0].getWidth();
                        el.next().setStyle({
                            'position' : 'absolute',
                            'top' : offset.top + height + 'px',
                            'left' : offset.left + 'px'
                        }).show();
                        //$(dd).show();
                        dd.addClassName('active');
                    }

                });
            });
        }
        if (this.layerStyle == '4') {
            $$('div.block-layered-nav dt').each(function(el) {
                Event.observe(el, 'click', function(e) {
                    e.stop();
                    var dd = el.next();
                    if (dd.hasClassName('active')) {
                        $(dd).hide();
                        dd.removeClassName('active');
                    } else {
                        self.hideAllNotActive();
                        var blockNav = el, offset = blockNav.positionedOffset(), height = blockNav.getHeight();
                        width = $$('.block-layered-nav')[0].getWidth();
                        el.next().setStyle({
                            'position' : 'absolute',
                            'top' : offset.top + height + 'px',
                            'left' : offset.left + 'px'
                        }).show();
                        //$(dd).show();
                        dd.addClassName('active');
                    }

                });
            });
        }

        $$('.tm_options_search').each(function(el) {
            Event.observe(el, 'keyup', function(e) {
                e.stop();
                if (el.value) {
                    var dd = el.up();
                    var li = dd.select('li');
                    var searchText = el.value;
                    li.each(function(option) {
                        var a = option.select('a');

                        if (undefined !== a[0]) {
                            var text = a[0].innerHTML;
                            var expr = new RegExp(searchText, 'ig');
                            if (-1 == text.search(expr)) {
                                option.hide();
                                if (self.countOption == 0) {
                                    return false;
                                }
                                if (self.layerStyle == '1') {
                                    dd.down('a.see-all-show').hide();
                                    dd.down('a.see-all-hide').hide();
                                }
                            } else {
                                option.show();
                            }
                        } else {
                            option.hide();
                        }
                    });
                } else {
                    var dd = el.up();
                    var li = dd.select('li');
                    var searchText = el.value;
                    li.each(function(option) {
                        option.show();
                    });
                    if (self.countOption == 0) {
                        return false;
                    }
                    if (self.layerStyle == '1') {
                        dd.down('a.see-all-hide').show();
                    }
                }
            });
        });

        $$('.ajax-option-link').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                self.reload.bind(self, this.href)();
            });
        });
        $$('#narrow-by-list .swatch-link, #mobile-layered-navigation .swatch-link').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (this.href) {
                    self.reload.bind(self, this.href)();
                }
            });
        });
        $$('.see-all-hide').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                self.showHideOption.bind(self, this)();
            });
        });

        $$('div.block-layered-nav dt').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                self.showHideTop.bind(self, this)();
            });
        });

        $$('.see-all-show').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                self.showHideOption.bind(self, this)();
            });
        });

        $$('.ajaxlayerednavigation-img-link').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                self.reload.bind(self, this.href)();
            });
        });

        $$('.ajax-option-select').each(function(el) {
            Event.observe(el, 'change', function(e) {
                if (this.value) {
                    self.reload.bind(self, this.value)();
                }
            });
        });

        $$('.ajax-option-checkbox').each(function(el) {
            Event.observe(el, 'click', function(e) {
                self.reload.bind(self, this.value)();
            });
        });

        // added filter by name
        $$('.aln-apply-name').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                var nameFilter = $('filter-by-name').value;
                if (self.useAjax) {
                    self.updateUrlHash('n', nameFilter);
                    self.checkUrlHash();
                } else {
                    var url = self.updateURLParameter(window.location.href, 'n', nameFilter);
                    self.reload(url);
                    //window.location.href = url;
                }
            });
        });

        $$('a.list').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    var url = '';
                    if (query) {
                        url = self.categoryUrl + query;
                    } else {
                        url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    self.reload(self._buildSeoQuery({
                        'mode' : 'list'
                    }));
                }
            });
        });

        $$('a.grid').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    self.reload(self._buildSeoQuery({
                        'mode' : 'grid'
                    }));
                }

            });
        });

        $$('div.sort-by select').each(function(el) {
            el.stopObserving('change');
            el.onchange = function() {
                return false;
            }
            Event.observe(el, 'change', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.value);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    var query = self.getUrlQuery(this.value);
                    var params = self.getSeoQuery(query);
                    if (query) {
                        self.reload(self._buildSeoQuery(params));
                    } else {
                        self.reload(self._buildSeoQuery({}));
                    }
                }
            });
        });

        $$('div.sort-by a').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    var query = self.getUrlQuery(this.href);
                    var params = self.getSeoQuery(query);
                    if (query) {
                        self.reload(self._buildSeoQuery(params));
                    } else {
                        self.reload(self._buildSeoQuery({}));
                    }
                }
            });
        });

        $$('a.sort-dir').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    var query = self.getUrlQuery(this.href);
                    var params = self.getSeoQuery(query);
                    if (query) {
                        self.reload(self._buildSeoQuery(params));
                    } else {
                        self.reload(self._buildSeoQuery({}));
                    }
                }
            });
        });

        $$('div.block-layered-nav div.actions a').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                self.reload.bind(self, el.href)();
            });

        });

        $$('div.limiter select').each(function(el) {
            el.stopObserving('change');
            el.onchange = function() {
                return false;
            }
            Event.observe(el, 'change', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.value);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    var query = self.getUrlQuery(this.value);
                    var params = self.getSeoQuery(query);
                    if (query) {
                        self.reload(self._buildSeoQuery(params));
                    } else {
                        self.reload(self._buildSeoQuery({}));
                    }
                }
            });
        });

        $$('div.limiter a').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    var query = self.getUrlQuery(this.href);
                    var params = self.getSeoQuery(query);
                    if (query) {
                        self.reload(self._buildSeoQuery(params));
                    } else {
                        self.reload(self._buildSeoQuery({}));
                    }
                }
            });
        });

        $$('div.block-layered-nav a.btn-remove').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                } else {
                    var url = this.href;
                }

                self.reload.bind(self, url)();
            });
        });

        $$('div.pages li a').each(function(el) {
            Event.observe(el, 'click', function(e) {
                e.stop();
                if (!self.seoUrls) {
                    var query = self.getUrlQuery(this.href);
                    if (query) {
                        var url = self.categoryUrl + query;
                    } else {
                        var url = self.categoryUrl;
                    }
                    self.reload.bind(self, url)();
                } else {
                    var query = self.getUrlQuery(this.href);
                    var params = self.getSeoQuery(query);
                    if (query) {
                        self.reload(self._buildSeoQuery(params));
                    } else {
                        self.reload(self._buildSeoQuery({}));
                    }
                }
            });
        });
    },

    checkUrlHash : function() {
        var url = this.categoryUrl;
        var hash = document.location.hash;
        if (hash != '') {
            if (!this.seoUrls) {
                var query = hash.replace('#', '?');
                url += query;
                this.urlHash = hash;
                this.reload(url);
            } else {
                var query = hash.replace('#', ''),
                    params = {},
                    hashParams = query.split('&'),
                    tmpItem = [];
                hashParams.each(function(item){
                    tmpItem = item.split('=');
                    params[tmpItem[0]] = tmpItem[1];
                });
                this.reload(this._buildSeoQuery(params));
            }
        }
    },

    ajaxSetInterval: function() {
        if (location.hash == '') {
            return;
        }
        if (this.seoUrls) {
            return false;
        }
        var self = this;
        this.intervalId = setInterval(function() {
            if (decodeURIComponent(self.urlHash) != decodeURIComponent(location.hash.replace('#', ''))) {
                self.reload(location.href.replace('#', '?'));
            }
        }, 100);
    },

    ajaxClearInterval : function() {
        clearInterval(this.intervalId);
    },

    removeHash: function () {
        var scrollV, scrollH, loc = window.location;
        if ("pushState" in history)
            history.pushState("", document.title, loc.pathname + loc.search);
        else {
            // Prevent scrolling by storing the page's current scroll offset
            var scrollOffset = document.viewport.getScrollOffsets();
            scrollV = scrollOffset.top;
            scrollH = scrollOffset.left;

            loc.hash = "";

            // Restore the scroll offset, should be flicker free
            window.scrollTo(scrollH, scrollV);
        }
    },

    fixLayerPosition: function() {
        var toolbar = $$('div.block-layered-nav').first();
        if (-50 > parseInt(toolbar.viewportOffset().top)) {
            Effect.ScrollTo(toolbar, { duration:'1', offset:-5 });
        }
    },

    reload : function(url) {
        url = decodeURIComponent(url);
        url = url.replace('%2B', '+');
        var self = this;
        if (self.intervalId != '') {
            self.ajaxClearInterval();
        }
        this.currentUrl = url;

        if (!self.seoUrls) {
            var query = this.getUrlQuery(url);
        } else {
            var query = this.getUrlQuery(url);
        }
        if (this.home) {
            if (query && this.useAjax) {
                hash = query.substr(1, query.length);
                this.urlHash = hash;
                window.location = this.categoryUrl + '#' + hash;
            } else {
                window.location = this.currentUrl;
            }
            return;
        }
        if (!self.seoUrls) {
            if (query && this.useAjax) {
                hash = query.substr(1, query.length);
                this.urlHash = hash;
                document.location.hash = hash;
            } else {
                if (this.useAjax) {
                    this.removeHash();
                }
            }
        } else {
            self.addSeoHash(url);
        }

        if (this.sliderFlag) {
            if (null !== $('hidden-url')) {
                $('hidden-url').value = this.categoryUrl;
            }

        }
        if (this.useAjax) {
            this.showLoader();
            var parser = document.createElement('a');
            parser.href = this.currentUrl;
            this.currentUrl = this.currentUrl.replace(/https{0,1}\:/, window.location.protocol);
            this.currentUrl = this.currentUrl.replace(parser.hostname, window.location.hostname);

            new Ajax.Request(this.currentUrl, {
                method : 'get',
                onSuccess : function(transport) {
                    var response = transport.responseText.evalJSON();
                    var colmain = $$('div.col-main')[0];
                    if ("undefined" == typeof colmain) {
                        colmain = $$('div.column-main')[0];
                    }
                    if (self.layerStyle == 0) {
                        colmain.update(response.brend + response.filter + response.list);
                    } else {
                        colmain.update(response.brend + response.list);
                        $$('div.block-layered-nav')[0].replace(response.filter);
                    }
                    self.hideLoader();
                    self.fixLayerPosition();
                    self.prepareMarkup();
                    setTimeout(function() {
                        self.prepareStyleMarkup();
                    }, 100);

                    // AjaxPro add observers
                    if (typeof AjaxPro !== "undefined") {
                        AjaxPro.fire('init');
                        AjaxPro.fire('addObservers');
                    }
                    self.addObservers();
                    self.hideAllOptions();
                    //quickshoping fix
                    if (typeof initQuickShoppingJs !== "undefined") {
                        $('lightwindow') && $('lightwindow').remove();
                        $('lightwindow_overlay') && $('lightwindow_overlay').remove();
                        initQuickShoppingJs();
                    }
                    updateAjaxLayeredSliders();
                    self.ajaxSetInterval();
                    // fire event product list ready
                    document.fire("ajaxlayerednavigation:ready");
                    if (typeof($j) !== 'undefined') {
                        $j(window).trigger('delayed-resize');
                    }
                }
            });
        } else {
            window.location = this.currentUrl;
        }
    },

    showLoader : function() {
        var layered = $('narrow-by-list');
        if (!layered) {
            return false;
        }

        layered.setOpacity(0.4);
        var eltLayer = layered;
        var loaderLayer = $('ajax-loading-layer');
        var eltDimsLayer = eltLayer.getDimensions();
        var yLayer = eltDimsLayer.height / 2;
        var xLayer = eltDimsLayer.width / 2;
        var posLayer = Position.cumulativeOffset(eltLayer);
        var leftLayer = posLayer[0] + xLayer;
        var topLayer = posLayer[1] + yLayer;
        var stylesLayer = {
            position : 'absolute',
            top : (topLayer - 16) + 'px',
            left : (leftLayer - 16) + 'px',
            zIndex : 999,
            display : 'block'
        };
        if (loaderLayer) {
            loaderLayer.setStyle(stylesLayer);
        }
    },

    hideLoader : function() {
        if (!$('narrow-by-list')) {
            return false;
        }
        var loaderLayer = $('ajax-loading-layer');
        var styles = {
            display : 'none'
        };
        if (loaderLayer) {
            loaderLayer.setStyle(styles);
        }
        $('narrow-by-list').setOpacity(1);
    },

    getUrlQuery : function(url) {
        var strHref = url;
        if (strHref.indexOf("?") > -1) {
            var strQueryString = strHref.substr(strHref.indexOf("?"));
            return strQueryString;
        }

        return false;
    },

    addSeoHash: function(url) {
        if (!this.useAjax) {
            return false;
        }

        var params = this._getAllUrlParams(url);

        var hash = '';
        hashAdd = false;
        for(var i in params) {
            if (undefined != params[i]) {
                hash = hash + i + '=' + params[i] + '&';
                hashAdd = true;
            }
        }
        hash = hash.slice(0,-1);
        if (!hashAdd) {
            this.removeHash();
        } else {
            document.location.hash = hash;
        }
    },

    _getAllUrlParams : function(Url) {
        if (this.seoUrls) {
            var newUrl ='';
            newUrl = Url.replace(this.seoCat+'/', '');
            newUrl = newUrl.replace(this.seoCat, '');
            newUrl = newUrl.replace(this.categoryUrl, '')
            newUrl = newUrl.replace(this.seoSuffix, '');
            newUrl = newUrl.replace('f/', '');
            var a = newUrl.split('/');
            var i;
            var output = {};

            for(i = 0; i < a.length; i += 2) {
                output[a[i]] = a[i + 1];
            }

            return output;
        } else {
            Url = Url.replace(/.*\?(.*?)/, "$1");
            Variables = Url.split("&");
            return Variables;
        }
    },

    _buildQuery : function(params) {
        if (this.seoUrls) {
            var oldParams = this._getAllUrlParams($('hidden-url').value);
            for (var i in oldParams) {
                if (i != 'price') {
                    params[i] = oldParams[i];
                }

            }
            var sortParams ={},
                keys = Object.keys(params),
                i, len = keys.length;

            keys.sort();

            for (i = 0; i < len; i++)
            {
                k = keys[i];
                sortParams[k] = params[k];
            }
            var query = '';
            for (var i in sortParams) {
                if (undefined !== params[i]) {
                    query = query + '/' + i + '/' + params[i];
                }
            }

            var finalUrl = '';
            var url = this.seoCat;
            finalUrl = url + query + this.seoSuffix;

            return finalUrl;
        } else {
            var oldParams = this._getAllUrlParams($('hidden-url').value);

            var defaultPrice = false;
            this.defaultSlderValues = false;

            oldParams.each(function(item) {
                if ('' == item) {
                    throw $break;
                }
                param = item.split('=');

                if (undefined === params[param[0]]) {
                    params[param[0]] = param[1];
                }
            });

            var query = [];
            for (var i in params) {
                if (undefined !== params[i]) {
                    query.push(i + '=' + params[i]);
                }
            }

            this.currentUrlParams = '?' + query.join('&');
            var url = this.categoryUrl.replace(this.categoryUrl.search, '');

            return url + this.currentUrlParams;
        }
    },

    _buildSeoQuery : function(params) {
        var oldUrl = '';
        if (undefined == this.currentUrl) {
            oldUrl = document.URL;
        } else {
            oldUrl = this.currentUrl;
        }

        var oldParams = this._getAllUrlParams(oldUrl);

        if (this.isCatalogSearch) {
            if (Object.keys(oldParams).length <= 1) {
                oldParams = { 'q' : this.searchQuery };
            }
        }
        for (var i in oldParams) {
            if (!params.hasOwnProperty(i)) {
                params[i] = oldParams[i];
            }
        }
        var sortParams ={},
            keys = Object.keys(params),
            i, len = keys.length;

        keys.sort();

        for (i = 0; i < len; i++)
        {
            k = keys[i];
            sortParams[k] = params[k];
        }
        var query = '';
        for (var i in sortParams) {
            if (undefined !== params[i]) {
                query = query + '/' + i + '/' + params[i];
            }
        }
        var finalUrl = '';
        var url = this.seoCat;
        finalUrl = url + query + this.seoSuffix;

        return finalUrl;
    },

    updateUrlHash: function(requestVar, value) {
        var hash = location.hash,
            newHash = '#',
            hashParams = [],
            i = 0
            hashLenght = 0;
        if (-1 != hash.indexOf(requestVar + "=")) {
            hash = hash.substr(1, hash.length);
            hashParams = hash.split('&');
            hashLenght = hashParams.length;

            hashParams.each(function(param){
                if (-1 !== param.indexOf(requestVar)) {
                    newHash += requestVar + '=' + value;
                } else {
                   newHash += param;
                }
                i++;

                if (i != hashLenght) { newHash += "&"; }
            });

            window.location.hash = newHash;
        } else {
            if (this.home && this.seoUrls) {
                if (this.useAjax) {
                    window.location = this.seoCat + this.seoSuffix + '#' + requestVar + '=' + value;
                } else {
                    window.location = this.seoCat + this.seoSuffix + '?' + requestVar + '=' + value;
                }
            } else {
                if (hash.length > 1) {
                    window.location.hash = hash + '&' + requestVar + '=' + value;
                } else {
                    window.location.hash = requestVar + '=' + value;
                }
            }
        }
    },

    updateURLParameter: function(url, param, paramVal) {
        var newAdditionalURL = "";
        var tempArray = url.split("?");
        var baseURL = tempArray[0];
        var additionalURL = tempArray[1];
        var temp = "";
        if (additionalURL) {
            tempArray = additionalURL.split("&");
            for (i=0; i<tempArray.length; i++){
                if(tempArray[i].split('=')[0] != param){
                    newAdditionalURL += temp + tempArray[i];
                    temp = "&";
                }
            }
        }

        var rows_txt = temp + "" + param + "=" + paramVal;
        return baseURL + "?" + newAdditionalURL + rows_txt;
    }
};

if (Prototype.Browser.IE && document.documentMode >= 9) {
    // IE 9 fix
    Control.Slider.prototype.startDrag = function(event) {
        if (0 == event.button) {
            if (!this.disabled) {
                this.active = true;

                var handle = Event.element(event);
                var pointer = [Event.pointerX(event), Event.pointerY(event)];
                var track = handle;
                if (track == this.track) {
                    var offsets = Position.cumulativeOffset(this.track);
                    this.event = event;
                    this.setValue(this.translateToValue((this.isVertical() ? pointer[1] - offsets[1] : pointer[0] - offsets[0]) - (this.handleLength / 2)));
                    var offsets = Position.cumulativeOffset(this.activeHandle);
                    this.offsetX = (pointer[0] - offsets[0]);
                    this.offsetY = (pointer[1] - offsets[1]);
                } else {
                    // find the handle (prevents issues with Safari)
                    while ((this.handles.indexOf(handle) == -1) && handle.parentNode)
                    handle = handle.parentNode;

                    if (this.handles.indexOf(handle) != -1) {
                        this.activeHandle = handle;
                        this.activeHandleIdx = this.handles.indexOf(this.activeHandle);
                        this.updateStyles();

                        var offsets = Position.cumulativeOffset(this.activeHandle);
                        this.offsetX = (pointer[0] - offsets[0]);
                        this.offsetY = (pointer[1] - offsets[1]);
                    }
                }
            }
            Event.stop(event);
        }
    }
}
